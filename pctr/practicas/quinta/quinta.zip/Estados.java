
public enum Estados {
    IDLE, WAITING, ACTIVE;
}
